﻿using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;

namespace CollectionViewTest
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        public class ROWDATA
        {
            public int ID = 0;
            public string FIELD1 { get; set; }
        }

        int CreatedRowCount = 0;

        private void btn_fill_Clicked(object sender, EventArgs e)
        {

            ObservableCollection<ROWDATA> ROWS = new ObservableCollection<ROWDATA>();

            for (int i = 0; i < 1000; i++)
                ROWS.Add(new ROWDATA() { ID = i, FIELD1 = Guid.NewGuid().ToString() });

            view.ItemTemplate = new DataTemplate(() =>
            {
                CreatedRowCount++;
                Debug.WriteLine("CreatedRowCount=" + CreatedRowCount);

                Grid g = new Grid();
                g.RowDefinitions.Add(new RowDefinition(new GridLength(40)));

                Label label_ID = new Label() { VerticalTextAlignment = TextAlignment.Center };
                label_ID.SetBinding(Label.TextProperty, "FIELD1");
                g.Children.Add(label_ID);

                return g;
            });

            view.ItemsSource = ROWS;
        }

    }

}
